/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Term 6/fpga/Zynq Tutorial/projects/temp3/maincode2.v";
static unsigned int ng1[] = {1U, 0U};
static unsigned int ng2[] = {0U, 0U};
static unsigned int ng3[] = {2U, 0U};
static unsigned int ng4[] = {3U, 0U};



static void Always_25_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    t1 = (t0 + 13728U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(25, ng0);
    t2 = (t0 + 14048);
    *((int *)t2) = 1;
    t3 = (t0 + 13760);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(25, ng0);

LAB5:    xsi_set_current_line(27, ng0);
    t4 = (t0 + 1048U);
    t5 = *((char **)t4);
    t4 = (t0 + 6728);
    xsi_vlogvar_wait_assign_value(t4, t5, 0, 0, 32, 0LL);
    xsi_set_current_line(28, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 6888);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 32, 0LL);
    xsi_set_current_line(29, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t0 + 7048);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 32, 0LL);
    xsi_set_current_line(30, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 7208);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 32, 0LL);
    xsi_set_current_line(31, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);

LAB6:    t2 = ((char*)((ng1)));
    t6 = xsi_vlog_unsigned_case_compare(t3, 2, t2, 2);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_compare(t3, 2, t2, 2);
    if (t6 == 1)
        goto LAB9;

LAB10:
LAB12:
LAB11:    xsi_set_current_line(34, ng0);
    t2 = ((char*)((ng2)));
    t4 = (t0 + 8648);
    xsi_vlogvar_wait_assign_value(t4, t2, 0, 0, 6, 0LL);

LAB13:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 1688U);
    t4 = *((char **)t2);
    t2 = (t0 + 7368);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 32, 0LL);
    xsi_set_current_line(39, ng0);
    t2 = (t0 + 2648U);
    t4 = *((char **)t2);
    t2 = (t0 + 9128);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(40, ng0);
    t2 = (t0 + 2968U);
    t4 = *((char **)t2);
    t2 = (t0 + 9448);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(41, ng0);
    t2 = (t0 + 3288U);
    t4 = *((char **)t2);
    t2 = (t0 + 9768);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(43, ng0);
    t2 = (t0 + 1848U);
    t4 = *((char **)t2);
    t2 = (t0 + 7528);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 32, 0LL);
    xsi_set_current_line(44, ng0);
    t2 = (t0 + 2808U);
    t4 = *((char **)t2);
    t2 = (t0 + 9288);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(45, ng0);
    t2 = (t0 + 3128U);
    t4 = *((char **)t2);
    t2 = (t0 + 9608);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(46, ng0);
    t2 = (t0 + 3448U);
    t4 = *((char **)t2);
    t2 = (t0 + 9928);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(48, ng0);
    t2 = (t0 + 7528);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 7688);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 32, 0LL);
    xsi_set_current_line(49, ng0);
    t2 = (t0 + 9288);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10088);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(50, ng0);
    t2 = (t0 + 9608);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 11048);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(51, ng0);
    t2 = (t0 + 9928);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 12008);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(53, ng0);
    t2 = (t0 + 7688);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 7848);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 32, 0LL);
    xsi_set_current_line(54, ng0);
    t2 = (t0 + 10088);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10248);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(55, ng0);
    t2 = (t0 + 11048);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 11208);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(56, ng0);
    t2 = (t0 + 12008);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 12168);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(58, ng0);
    t2 = (t0 + 7848);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 8008);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 32, 0LL);
    xsi_set_current_line(59, ng0);
    t2 = (t0 + 10248);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10408);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(60, ng0);
    t2 = (t0 + 11208);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 11368);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(61, ng0);
    t2 = (t0 + 12168);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 12328);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 8008);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 8168);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 32, 0LL);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 10408);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10568);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(65, ng0);
    t2 = (t0 + 11368);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 11528);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(66, ng0);
    t2 = (t0 + 12328);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 12488);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(68, ng0);
    t2 = (t0 + 8168);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 8328);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 32, 0LL);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 10568);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10728);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 11528);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 11688);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(71, ng0);
    t2 = (t0 + 12488);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 12648);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(73, ng0);
    t2 = (t0 + 8328);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 8488);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 32, 0LL);
    xsi_set_current_line(74, ng0);
    t2 = (t0 + 10728);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10888);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(75, ng0);
    t2 = (t0 + 11688);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 11848);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 12648);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 12808);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(78, ng0);
    t2 = (t0 + 1368U);
    t4 = *((char **)t2);
    t2 = (t0 + 4648);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 2, 0LL);
    xsi_set_current_line(80, ng0);
    t2 = (t0 + 4648);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 4808);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(82, ng0);
    t2 = (t0 + 4808);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 4968);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 4968);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 5128);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 5128);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 5288);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(88, ng0);
    t2 = (t0 + 5288);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 5448);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(90, ng0);
    t2 = (t0 + 5448);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 5608);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(92, ng0);
    t2 = (t0 + 5608);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 5768);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(94, ng0);
    t2 = (t0 + 5768);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 5928);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(96, ng0);
    t2 = (t0 + 5928);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 6088);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(98, ng0);
    t2 = (t0 + 6088);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 6248);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 6248);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 6408);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(100, ng0);
    t2 = (t0 + 6408);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 6568);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 2, 0LL);
    xsi_set_current_line(101, ng0);
    t2 = (t0 + 6568);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);

LAB14:    t7 = ((char*)((ng4)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t7, 3);
    if (t6 == 1)
        goto LAB15;

LAB16:
LAB18:
LAB17:    xsi_set_current_line(108, ng0);

LAB21:    xsi_set_current_line(109, ng0);
    t2 = (t0 + 7368);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 4008);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 32, 0LL);
    xsi_set_current_line(110, ng0);
    t2 = (t0 + 9128);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 4168);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 9448);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 4328);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(112, ng0);
    t2 = (t0 + 9768);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 4488);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);

LAB19:    goto LAB2;

LAB7:    xsi_set_current_line(32, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t0 + 8648);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 6, 0LL);
    goto LAB13;

LAB9:    xsi_set_current_line(33, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 8648);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 6, 0LL);
    goto LAB13;

LAB15:    xsi_set_current_line(102, ng0);

LAB20:    xsi_set_current_line(103, ng0);
    t8 = (t0 + 8488);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t0 + 4008);
    xsi_vlogvar_wait_assign_value(t11, t10, 0, 0, 32, 0LL);
    xsi_set_current_line(104, ng0);
    t2 = (t0 + 10888);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 4168);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(105, ng0);
    t2 = (t0 + 11848);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 4328);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(106, ng0);
    t2 = (t0 + 12808);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 4488);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);
    goto LAB19;

}


extern void work_m_00000000000791606140_0323637447_init()
{
	static char *pe[] = {(void *)Always_25_0};
	xsi_register_didat("work_m_00000000000791606140_0323637447", "isim/maincode2test_isim_beh.exe.sim/work/m_00000000000791606140_0323637447.didat");
	xsi_register_executes(pe);
}
