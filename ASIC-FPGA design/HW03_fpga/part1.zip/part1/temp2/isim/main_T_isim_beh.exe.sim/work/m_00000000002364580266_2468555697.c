/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Term 6/fpga/Zynq Tutorial/projects/temp2/main_T.v";
static const char *ng1 = "withIPPower.vcd";
static int ng2[] = {1, 0};
static const char *ng3 = "main_T.uut";



static void Initial_50_0(char *t0)
{
    char *t1;

LAB0:    xsi_set_current_line(50, ng0);

LAB2:    xsi_set_current_line(51, ng0);
    xsi_vcd_dumpfile(ng1);
    xsi_set_current_line(52, ng0);
    t1 = ((char*)((ng2)));
    xsi_vcd_dumpvars_args(*((unsigned int *)t1), t0, (char)115, ng3, (char)101);

LAB1:    return;
}


extern void work_m_00000000002364580266_2468555697_init()
{
	static char *pe[] = {(void *)Initial_50_0};
	xsi_register_didat("work_m_00000000002364580266_2468555697", "isim/main_T_isim_beh.exe.sim/work/m_00000000002364580266_2468555697.didat");
	xsi_register_executes(pe);
}
