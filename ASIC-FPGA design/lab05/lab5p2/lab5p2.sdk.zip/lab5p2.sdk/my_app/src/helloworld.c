#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xgpio.h"
int main()
{
    init_platform();
    XGpio A;
    XGpio B;
    XGpio op;
    XGpio result;

    XGpio_Initialize(&A, XPAR_AXI_GPIO_0_DEVICE_ID);
    XGpio_Initialize(&B, XPAR_AXI_GPIO_0_DEVICE_ID);
    XGpio_Initialize(&op, XPAR_AXI_GPIO_1_DEVICE_ID);
    XGpio_Initialize(&result, XPAR_AXI_GPIO_1_DEVICE_ID);

    XGpio_SetDataDirection(&A, 1, 0x0000);
    XGpio_SetDataDirection(&B, 2, 0x0000);
    XGpio_SetDataDirection(&op, 1, 00);
    XGpio_SetDataDirection(&result, 2, 0xffff);

    unsigned int random_number_A , random_number_B , random_op , random_result , alu_result;

       // Seed the random number generator with the current time
       srand(400102233);
       long int i , s;
       s = 0;
       for(i = 0; i < 1000000 ; i++){
    	   random_number_A = rand() ^ (rand() << 15) ^ (rand() << 30);
    	   random_number_B = rand() ^ (rand() << 15) ^ (rand() << 30);
    	   random_op = rand() % 4;
    	   //random_number_A = 31;
    	   //random_number_B = 23;
    	   //random_op = 0;
    	   switch(random_op){
    	   case(0):
		random_result =  random_number_A + random_number_B;
    	   break;
    	   case(1):
		random_result =  random_number_A - random_number_B;
    	   break;
    	   case(2):
		random_result =  ~(random_number_A & random_number_B);
    	   break;
    	   case(3):
		random_result =  ~(random_number_A | random_number_B);
    	   break;
    	   }
    	   XGpio_DiscreteWrite(&A, 1, random_number_A);
    	   XGpio_DiscreteWrite(&B, 2, random_number_B);
    	   XGpio_DiscreteWrite(&op, 1, random_op);
    	   alu_result = XGpio_DiscreteRead(&result, 2);
    	   if(alu_result != random_result){
    		   printf("\tError: A = %8x,B = %8x,op=%d , expected: %8x, but got: %8x\n" ,random_number_A , random_number_B , random_op , random_result , alu_result );
    		   s ++;
    		   sleep(2);
    	   }
       }
       xil_printf("total tests implemented = %d\n" , 10000000);
       if(s==0){
        printf("\n\n\tWaw!! NO ERROR Found. Great Job.\n\n");
       }
       else{
            if(s==1){
                printf("1 error was found! :(");
            }
            else{
                printf("%d errors were found! :(" , s);
            }

       }





    //print("Hello World\n\r");

    cleanup_platform();
    return 0;
}
